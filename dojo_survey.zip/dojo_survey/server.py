from flask import Flask, render_template, redirect, request

dojo_survey = Flask(__name__)

@dojo_survey.route('/')
def form():
	return render_template("index.html")

@dojo_survey.route("/result", methods=['POST'])
def submit():
	name = request.form["name"]
	location = request.form["location"]
	language = request.form["language"]
	comment = request.form["comment"]
	print name, location, language, comment
	# return redirect("/")
	return render_template("result.html", display_name=name, display_location=location, display_language=language, display_comment=comment)

dojo_survey.run(debug=True)
